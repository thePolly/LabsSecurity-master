package ru;

public interface SocketProxy {

    void accept();

}
